
import gtk
import gobject

class T(gtk.Adjustment):
    def __init__(self):
        gtk.Adjustment.__init__(self)
        
