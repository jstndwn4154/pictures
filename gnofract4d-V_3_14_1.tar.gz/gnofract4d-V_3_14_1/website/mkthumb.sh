#!/bin/sh

convert $1.png -resize 150x113 thumbnail_$1.jpg
