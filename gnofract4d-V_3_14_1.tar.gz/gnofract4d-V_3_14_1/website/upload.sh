#!/bin/sh
scp *.html catenary,gnofract4d@web.sourceforge.net:/home/groups/g/gn/gnofract4d/htdocs/
scp manual/*.html catenary,gnofract4d@web.sourceforge.net:/home/groups/g/gn/gnofract4d/htdocs/manual
