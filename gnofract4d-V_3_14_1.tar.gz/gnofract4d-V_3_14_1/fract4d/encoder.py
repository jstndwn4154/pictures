
import gst

class T:
    def __init__(self):
        pass

