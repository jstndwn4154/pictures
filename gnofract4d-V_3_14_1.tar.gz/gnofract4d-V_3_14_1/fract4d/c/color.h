
#ifndef COLOR_H_
#define COLOR_H_

struct s_rgba;

typedef struct s_rgba rgba_t;

struct s_rgba
{
    unsigned char r,g,b,a;
};

#endif /* COLOR_H_ */
